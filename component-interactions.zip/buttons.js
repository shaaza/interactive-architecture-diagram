let buttons = {
  sliderButton: {
    state: false, 
    activeText: "pause & slide off (spacebar)", 
    inactiveText: "pause & slide on (spacebar)", 
   coords: {x: 10, y: drawingAreaMaxY + topInfoAreaHeight + 10}
  },
  resetButton: {
    state: false,
    activeText: "reset current message (r)",
    inactiveText: "reset current message (r)",
    coords: {x: 10, y: drawingAreaMaxY + topInfoAreaHeight + 30}
  },
  showSchemaButton: {
    state: false,
    activeText: "hide schemas (s)",
    inactiveText: "show schemas (s)",
    coords: {x: 10, y: drawingAreaMaxY + topInfoAreaHeight + 50}
  }
};

function drawButton(button) {
  let state = button.state;
  let textOn = button.activeText, textOff = button.inactiveText;
  let x = button.coords.x; y = button.coords.y;
  if (state) {
    fill(pink);
    stroke(pink);
    text(textOn, x + 45, y + 7.5);
    rect(x, y, 40, 10);
  } else {
    fill(black);
    stroke(black);
    text(textOff, x + 45, y + 7.5);
    rect(x, y, 40, 10);
  }
}
