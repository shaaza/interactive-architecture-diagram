const defaultFillColor = bluepalette[0];

class Component {
  constructor({name = Math.random()*1000, x = 0, y = 0, side = defaultBoxSide, fillColor = defaultFillColor, textColor = black}) {
    this.name = name;
    this.side = side;
    this.x = x
    this.y = y
    this.fillColor = fillColor
    this.textColor = textColor
  }

  // Method
  draw() {
      mybox(this.x, this.y, this.side, this.fillColor, this.name, this.textColor)
  }
  
  updateFillColor(newColor) {
    this.fillColor = newColor
  }
  
  rotateFillColorPalette(pallette) {
    if (pallette.indexOf(this.fillColor) < 0) {
       this.fillColor = pallette[0]; 
    } else {
      let currentColorIndex = pallette.indexOf(this.fillColor);
      let newColorIndex = (currentColorIndex + 1) % pallette.length;
      this.fillColor = pallette[newColorIndex];
    }
    
  }
  
  coordinates() {
    return {x: this.x, y: this.y}
  }
  
  isPointWithin(x, y, delta) {
    return x > this.x-delta && x < this.x + this.side + delta && y > this.y - delta && y < this.y + this.side + delta
  }
  
  shift(newX, newY) {
    this.x = newX
    this.y = newY
  }
  
  centre() {
    return {x: this.x + (this.side/2), y: this.y + (this.side/2)}
  }
}

function mybox(x, y, side, fillColor, textString, textColor) {
  fill(fillColor);
  stroke(fillColor);
  rect(x, y, side, side)
  fill(textColor);
  noStroke();
  text(textString, x, y)
}