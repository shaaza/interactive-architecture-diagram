const pink = [236, 236, 236];
const indigo = [215, 204, 250];
const white = [255, 255, 255];
const black = [0, 0, 0];
const blue = [0, 0, 255];
const skyblue = [135, 206, 235];
const green = [100, 215, 100];
const red = [155, 0, 0];  


const darkblue = [2, 62, 138];
const mediumblue = [0, 119, 182];
const lightblue = [144, 224, 239];
const paleblue = [202, 240, 248];
const bluepalette = [darkblue, mediumblue, lightblue, paleblue].reverse();
